# Bully_Algorithm
Project for CS255 Design and Analysis of Algorithms

Implementation of Bully algorithm and Modified Bully algorithm.

