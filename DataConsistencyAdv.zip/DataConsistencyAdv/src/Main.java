import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Scanner;

public class Main {
    public static void main(String args[])throws Exception {
        int i,j,k;
        /*
         * Initialising the Reader Writer threads..
         * */
        Writer writers[]=new Writer[20];
        Reader readers[]=new Reader[20];
        System.out.println("Enter The Number Of Reader and Writer Threads");
                Scanner s=new Scanner(System.in);
        j=s.nextInt();
        i=s.nextInt();
        FileOutputStream fw1=new FileOutputStream("File1.txt",true);
        FileOutputStream fw2=new FileOutputStream("File2.txt",true);
        FileOutputStream fw3=new FileOutputStream("File3.txt",true);
        /*
         * Setting the monitor on the shared resource i.e. the text file
         * */
        int uid[] = new int[i];
        for (int l = 0; l < i; l++) {
            System.out.println("Enter student UID to enroll in DC course: ");
            uid[l] = s.nextInt();
        }
        System.out.println("Initializing Monitor");
        Monitor m=new Monitor(fw1, fw2, fw3);
        System.out.println("Starting The Threads:");
        for(k=0;k<j;k++) {
            readers[k]=new Reader(m,new FileReader("File1.txt"), new FileReader("File2.txt"), new FileReader("File3.txt"));
            readers[k].start();
        }
        for(k=0;k<i;k++) {
            writers[k]=new Writer(m, uid[k]);
            writers[k].start();
        }
    }
}
