import java.io.FileReader;
public class Reader extends Thread {
    private FileReader fr1, fr2, fr3;
    private Monitor m;
    Reader(Monitor m, FileReader fr1, FileReader fr2, FileReader fr3) {
        this.fr1=fr1;
        this.fr2=fr2;
        this.fr3=fr3;
        this.m=m;
    }
    public void run() {
        int randomNum = (int)(Math.random()*(2-0+1)+0);
        try {
            if(randomNum == 0){
                m.read(fr1, 1);
                fr1.close();
            }else if(randomNum == 1){
                m.read(fr2, 2);
                fr2.close();
            }else{
                m.read(fr3, 3);
                fr3.close();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}
