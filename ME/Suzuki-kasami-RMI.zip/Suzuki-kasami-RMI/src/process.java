import RMI.Suzuki_kasami;
import RMI.Suzuki_kasami_rmi;
import RMI.Token;

import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class process {

        private static String URL_PREFIX = "rmi://localhost/process%d";
        private static String URL_REGEX = "^process([0-9]+)$";

        static int numProcesses;
        static int indexProcess;
        static String fileName;
        static int capacity;
        static int velocity;
        static int delay;
        static boolean bearer;
        static String[] urls;
        static boolean creatorRegistry;
        static Registry registry = null;

        public static void main(String[] args) {

                if (args.length < 6) {
                        System.out.println("Usage: java process <num_processes> <file_name> <capacity> <velocity> <delay> <bearer>");
                        System.exit(1);
                }

                parseArgs(args);

                for (int i = 0; i < urls.length; i++) {
                        urls[i] = String.format(URL_PREFIX, i);
                }

                initRmiRegistry();
               
                getIndexByRegisterListed();

                Suzuki_kasami_rmi process = null;

                try {
                        process = new Suzuki_kasami(urls, indexProcess, capacity, velocity);
                        Naming.bind(urls[indexProcess], process);
                } catch (RemoteException | MalformedURLException | AlreadyBoundException e) {
                        try {
                                Naming.rebind(urls[indexProcess], process);
                        } catch (RemoteException | MalformedURLException e1) {
                                e1.printStackTrace();
                        }
                }

                Token token = null;
                if (bearer) {
                        System.out.println("Instantiating Token");
                        token = new Token(numProcesses, capacity, fileName);
                }

                //we wait for delay, to initialize the extractor process
                try {
                        Thread.sleep(delay);
                } catch (InterruptedException e) {
                        e.printStackTrace();
                }

                // start the extractor process
                try {
                        process.initializeExtractProcess(token);
                } catch (RemoteException e) {
                        e.printStackTrace();
                }

                //if you are the creator of the rmi record, you must wait for others to finish
                //to avoid falling into interrupts.
                if(creatorRegistry){
                        System.out.println("Waiting for completion of other processes to download rmi register");
                        try {
                                Thread.sleep(1500);
                        } catch (InterruptedException e) {
                                e.printStackTrace();
                        }
                }
                System.out.println("Finished extraction process");
                System.exit(0);
        }

        /**
         * Get an id and url for the current process, based on the rmi logs
         * already bound in the algorithm.
         */
        private static void getIndexByRegisterListed() {
                String[] endPoints = null;
                try {
                        endPoints = registry.list();
                } catch (RemoteException e) {
                        e.printStackTrace();
                }

                if (endPoints.length > 0) {
                        String endString = endPoints[endPoints.length - 1];
                        Pattern pattern = Pattern.compile(URL_REGEX);

                        Matcher matcher = pattern.matcher(endString);
                        if (matcher.matches()) {
                                indexProcess = Integer.valueOf(matcher.group(1)) + 1;
                        } else {
                                System.out.println("There was a problem binding the rmi url");
                                System.exit(1);
                        }

                }
        }

        /**
         * Method to initialize rmi registry in port 1099, if it is already created, it is
         * skip method.
         */
        private static void initRmiRegistry() {
                // RMI init
                try {
                        LocateRegistry.createRegistry(1099);
                } catch (RemoteException e2) {
                        creatorRegistry = false;
                        System.out.println("rmi record was already created, skip");
                }

                try {
                        registry = LocateRegistry.getRegistry();
                } catch (RemoteException e) {
                        e.printStackTrace();
                }
        }

        /**
         * Method to parse program arguments
         *
         * @param args String array with properties.
         */
        private static void parseArgs(String[] args) {
                numProcesses = Integer.parseInt(args[0]);
                fileName = args[1];
                capacity = Integer.parseInt(args[2]);
                velocity = Integer.parseInt(args[3]);
                delay = Integer.parseInt(args[4]);
                bearer = ( (args[5].compareTo("True") == 0 || args[5].compareTo("true") == 0 ) ? true : false);
                urls = new String[numProcesses];
                creatorRegistry = true;
        }

}