package RMI;

public class ProcessState {

        public enum Status {
                IDLE, WAITINGTOKEN, CRITICALSECTION
        }

        public Status status;

        public ProcessState() {
                this.status = Status.IDLE;
        }

        public String toString() {
                String message = "";

                switch (status) {
                case IDLE:
                        message = "Idle";
                        break;
                case WAITINGTOKEN:
                        message = "Speed token";
                        break;
                case CRITICALSECTION:
                        message = "critical section";
                        break;

                default:
                        break;
                }

                return message;
        }
}