package RMI;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.Queue;

public class Token implements Serializable {

        private static final long serialVersionUID = 20120731125400L;

        private Queue<Integer> queue;
        private int[] ln;
        private int capacity;
        private Boolean isInstantiated = false;
        // private String  contentFile = "";
        private String fileName = "";
        private int charactersRemaining;
        private  int initialCharacters;

        public static final String ANSI_RESET = "\u001B[0m";
        public static final String ANSI_RED = "\u001B[31m";
        public static final String ANSI_GREEN = "\u001B[32m";
        public static final String ANSI_YELLOW = "\u001B[33m";
        public static final String ANSI_BLUE = "\u001B[34m";
        public static final String ANSI_BOLD = "\u001B[1m";

        public Token(int numProcesses, int inCapacity, String fileName) {
                if (!isInstantiated) {

                        isInstantiated = true;
                        capacity = inCapacity;
                        this.fileName = fileName;
                        try (
                                BufferedReader bReader = new BufferedReader(new FileReader(fileName));
                        ) {
                                // know amount of resource (letters) available
                                charactersRemaining = countInitialResources(bReader);
                                bReader.close();
                        } catch (FileNotFoundException e) {
                                e.printStackTrace();
                        } catch (IOException e) {
                                e.printStackTrace();
                        }
                        System.out.println("initial appeal:" + charactersRemaining);
                        queue = new LinkedList<Integer>();
                        ln = new int[numProcesses];
                        for (int i = 0; i < numProcesses; i++) {
                                ln[i] = 0;
                        }       
                }
        }

        /**
         * Count initial resource
         * @paramreader
         * @return
         * @throws IOException
         */
        private int countInitialResources(BufferedReader reader) throws IOException {
                String data = "";
                while ((data = reader.readLine()) != null) {
                        charactersRemaining += data.length();
                }
                initialCharacters = charactersRemaining;
                return charactersRemaining;
        }

        /**
         * Get sequence number LN[position] of the process
         *
         * @param index position of the process
         * @return sequence number registered in LN
         */
        public int getLni(int index) {
                return ln[index];
        }

        /**
         * Register sequence number in LN of the process
         *
         * @param index index in LN
         * @param value value to register
         */
        public void setLni(int index, int value) {
                ln[index] = value;
        }

        /**
         * Check if Queue contains the process id
         *
         * @param id id of the process to check
         * @return Whether the process id is queued or not.
         */
        public Boolean queueContains(int id) {
                return queue.contains(id);
        }

        /**
         * Check if queue is empty
         *
         * @return
         */
        public Boolean queueIsEmpty() {
                return queue.isEmpty();
        }

        /**
         * Add process id to Queue
         *
         * @param id id of the process
         */
        public void addId(int id) {
                queue.add(id);
        }

        /**
         * Remove element at head of Queue
         *
         * @return id of the removed process
         */
        public int popId() {
                return queue.remove();
        }

        /**
         * Obtain the extraction capacity allowed
         *
         * @return ability
         */
        public int getCapacity() {
                return capacity;
        }

        /**
         * Get the number of remaining characters
         *
         * @return ability
         */
        public int getCharactersRemaining() {
                return charactersRemaining;
        }

        /**
         * Get file name
         *
         * @return file name
         */
        public String getFileName() {
                return fileName;
        }

        /**
         * Get color to be written to console,
         * depending on the amount of resource available
         * @return
         */
        private String getColor(){
                
                double percent = 100*((double)charactersRemaining/initialCharacters);
                if(100.0>=percent && percent>=75.0 ){
                        return ANSI_BLUE;
                } 
                if(75.0>=percent && percent>=50.0 ){
                        return ANSI_GREEN;
                }
                if(50.0>=percent && percent>=25.0 ){
                        return ANSI_YELLOW;
                }
                
                return ANSI_RED;
        }

        /**
         * Gets color and deducts amount of remaining resource.
         * @return
         */
        public String readCharacter() {

                String readed = getColor() + ANSI_BOLD ;//+ String.valueOf( contentFile.charAt(0) ) + ANSI_RESET ;
                
                if(charactersRemaining > 0){
                        charactersRemaining -= 1;
                }
                return readed;
        }
}