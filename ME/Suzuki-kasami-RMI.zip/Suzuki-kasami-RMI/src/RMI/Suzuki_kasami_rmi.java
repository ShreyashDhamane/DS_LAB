package RMI;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Suzuki_kasami_rmi extends Remote {

        /**
         * Request to enter lyrics extraction
         *
         * @param token token, single object, can be passed as argument
         * in case the process has the token at the beginning of the algorithm.
         * @throwsRemoteException
         */
        public void initializeExtractProcess(Token token) throws RemoteException;

        /**
         * logs a request from a (remote) process
         *
         * @param id id of the process making the request
         * @param seq process request number
         * @throwsRemoteException
         */
        public void request(int id, int seq) throws RemoteException;

        /**
         * tells a remote process to wait for the token to perform the
         * critical section
         *
         * @throwsRemoteException
         */
        public void waitToken() throws RemoteException;

        /**
         * Take ownership of the token in the process
         *
         * @param token object token
         * @throwsRemoteException
         */
        public void takeToken(Token token) throws RemoteException;

        /**
         * Kill the remote process. It should be used to stop the S-K algorithm once
         * that the token has passed through all the nodes of the system
         *
         * @throwsRemoteException
         */
        public void kill() throws RemoteException;

}