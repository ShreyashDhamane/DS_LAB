package RMI;

import RMI.ProcessState.Status;

import java.io.*;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class Suzuki_kasami extends UnicastRemoteObject implements Suzuki_kasami_rmi {

        /**
        * Necessary when we implement the remote interface
        */
        private static final long serialVersionUID = 4466469363475602035L;


        /**
         * Delay to return a check if we have the token.
         * Design problem: busy waiting
         */
        private static final int TOKEN_WAIT_DELAY = 10;

        /**
         * Array containing the sequence number of the processes, where
         *           * RN[j] is the last sequence number received from process j.
         */
        private List<Integer> RN = null;

        /**
         * Current process index
         */
        private int index = 0;

        /**
         * Number of processes participating in the algorithm
         */
        private int numProcesses = 0;

        /**
         * Process URLs in the algorithm
         */
        private String[] urls = null;

        /**
         * Unique object in the system, which authorizes the passage to the
         *           * critical section. The process when obtaining it, enters the SC.
         */
        private Token token = null;

        /**
         * Extraction capacity of a process. Means
         *           * the number of letters that can be extracted in the critical section.
         */
        private int capacity = 0;

        /**
         * Letter extraction speed. (Number of letters/sec)
         */
        private long velocity = 1;

        /**
         * (Cooldown) Time the process waits before returning to
         *           * ask for the token.
         */
        private long cooling = 0;

        /**
         * If the process is in SC.
         */
        private boolean inCriticalSection = false;

        /**
         * State of the process
         */
        private ProcessState processState = null;

        /**
         * Whether the process was taken down or killed.
         */
        private Boolean killed = false;

        /**
         * Default constructor following RMI conventions
         *
         * @param urls  URLs of participating processes
         * @param index index of current process
         * @throws RemoteException if RMI mechanisms fail
         */
        public Suzuki_kasami(String[] urls, int index, int capacity, int velocity) throws RemoteException {
                super();

                this.index = index;
                this.urls = urls;
                this.numProcesses = urls.length;
                this.capacity = capacity;
                this.cooling = (long) ((double) (capacity * 1000) / (2.0 * velocity));
                this.velocity = (long) ((1. / velocity) * 1000);
                System.out.println("Speed: " + this.velocity + " -- Cooling: " + this.cooling);
                reset();
                printStatus();
        }

        // begin RMI implementation

        public void request(int id, int seq) throws RemoteException {
                // update seq number of process id
                // the maximum between the RN[id] and seq
                RN.set(id, Math.max(RN.get(id), seq));

                // if I am not in the critical section, I have the token and the request is not mine
                if (!inCriticalSection && token != null) {
                        if (index != id && (RN.get(id) > token.getLni(id))) {
                                String url = "rmi://localhost/process" + id;
                                int leftCharacts = token.getCharactersRemaining();
                                giveToken(url);
                                reinitialize(leftCharacts);
                        }
                }
        }

        public void waitToken() throws RemoteException {
                processState.status = Status.WAITINGTOKEN;
                printStatus();
                while (token == null && killed == false) {
                        try {
                                Thread.sleep(TOKEN_WAIT_DELAY);
                        } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                        }
                }
        }

        public void takeToken(Token token) throws RemoteException {
                inCriticalSection = true;
                this.token = (Token) token;
                processState.status = Status.CRITICALSECTION;
                printStatus();
        }

        public void kill() throws RemoteException {
                System.out.println("killing process");
                killed = true;
        }

        public void initializeExtractProcess(Token token) throws RemoteException {
                printRN();
                // broadcast request access to SC
                RN.set(index, RN.get(index) + 1);
                // send request to all other algorithm processes
                for (String url : urls) {
                        Suzuki_kasami_rmi dest;
                        try {
                                dest = (Suzuki_kasami_rmi) Naming.lookup(url);
                                dest.request(index, RN.get(index));
                        } catch (MalformedURLException |NotBoundException  e) {
                        }
                }
                if(token != null) {
                        //if we have token, start extraction
                        inCriticalSection = true;
                        this.token = (Token) token;
                        processState.status = Status.CRITICALSECTION;
                        printStatus();
                } else{
                        // expect token
                        waitToken();
                }
                if( killed == false ){
                        extract();
                        leaveToken();
                }
        }

        // end RMI implementation

        // begin private implementation

        /**
         * Prints by console the current status of the process
         */
        private void printStatus() {
                System.out.println("\u001B[1mStatus: " + processState.toString() + "\u001B[0m");
        }

        /**
         * Reinitializes the process, sets in initial values of execution of a process
         * in the algorithm.
         */
        private void reset() {
                //re-initialize RN array
                this.RN = new ArrayList<Integer>(numProcesses);
                for (int i = 0; i < numProcesses; i++) {
                        RN.add(0);
                }
                //idle state of the process
                processState = new ProcessState();
                token = null;
                inCriticalSection = false;
        }

        /**
         * Reads "amount" of letters from the file and removes them from the text file
         * @param "number" number of letters to remove from the beginning of the file
         * @return String with the letters extracted and removed from the file
         */
        private String readWrite(int amount){
                String read = "";
                //file lines, to remove when extracting
                List<String> lines = null;
                try (
                        //buffer to read letters to extract
                        BufferedReader bReader = new BufferedReader(new FileReader(token.getFileName()));
                ) {
                        Path path = FileSystems.getDefault().getPath("", token.getFileName());
                        lines = Files.readAllLines(path , StandardCharsets.UTF_8);

                        int index = 0;
                        int sacaTmp = amount;
                        while(read.length() < amount){
                                String line = lines.get(index);
                                if(line.length() < sacaTmp){
                                        //if it should read more than one line
                                        read += line;
                                        sacaTmp -= line.length();
                                        //remove line
                                        lines.remove(index);
                                } else{
                                        //if read less than one line
                                        read += line.substring(0, sacaTmp);
                                        //remove the extracted
                                        lines.set(index,line.substring(sacaTmp,line.length()));
                                        index++;
                                }
                        }
                        bReader.close();
                } catch (IOException e) {
                        e.printStackTrace();
                }

                try(
                        BufferedWriter bWriter = new BufferedWriter(new FileWriter(token.getFileName()));
                ){
                        // write to file
                        for (int i = 0; i < lines.size(); i++) {
                                if(lines.get(i).length() > 0) {
                                        bWriter.write(lines.get(i));
                                        if(i != lines.size() - 1){
                                                bWriter.write("\n");
                                        }
                                }
                        }
                        bWriter.close();
                } catch(IOException e){
                        e.printStackTrace();
                }

                return read;
        }

        /**
         * Hand over the token to a remote process
         * @param url url of the remote process
         */
        private void giveToken(String url){
                Suzuki_kasami_rmi dest;
                try {
                        // find process by lookup
                        dest = (Suzuki_kasami_rmi) Naming.lookup(url);
                        //we deliver the token to the destination
                        dest.takeToken(token);
                } catch (MalformedURLException | RemoteException | NotBoundException e) {
                        e.printStackTrace();
                }
                token = null;
                // update process status
                processState.status = Status.IDLE;
                printStatus();
        }

        /**
         * Reinitializes the token request in case
         * more than zero characters left in the file
         * @param leftCharacts number of letters the current process knows
         * that remain in the token.
         */
        private void reinitialize(int leftCharacts){

                if (leftCharacts > 0) {
                        // request the token for a new round
                        try {
                                Thread.sleep(cooling);
                                this.initializeExtractProcess(null);
                        } catch (InterruptedException | RemoteException e) {
                                e.printStackTrace();
                        }
                }
        }

        /**
         * Start extracting lyrics from the file, it is required
         * that the process is within the SC.
         */
        private void extract(){
                // sure we have token
                // we take the minimum between the remaining characters and the capacity
                int saca = Math.min(token.getCharactersRemaining(), capacity);
                System.out.println("Extraction:");

                // extract the letters and update the file
                String readed = readWrite(saca);

                for (int i = 0; i < saca; i++) {
                        // color format given by token
                        System.out.print(token.readCharacter());
                        System.out.print(readed.charAt(i) + "\u001B[0m" );
                        try {
                                //velocity like sleep
                                Thread.sleep(velocity);
                        } catch (InterruptedException e) {
                                e.printStackTrace();
                        }
                }
                if (saca > 0) {
                        System.out.println();
                }
        }

        /**
         * Method that leaves the current token, it is also the
         * responsible for sending the token to other processes that
         * have pending requests.
         */
        private void leaveToken()  {
                //update LN in token
                token.setLni(index, token.getLni(index) + 1);
                for (int i = 0; i < numProcesses; i++) {
                        if (!token.queueContains(i)) {
                                if (RN.get(i) == (token.getLni(i) + 1)) {
                                        token.addId(i);
                                }
                        }
                }
                // if the queue is not empty
                Suzuki_kasami_rmi dest = null;
                int leftCharacts = token.getCharactersRemaining();
                if (!token.queueIsEmpty() && leftCharacts > 0) {
                        // deliver token
                        int idProcess = token.popId();
                        giveToken("rmi://localhost/process" + idProcess);
                        reinitialize(leftCharacts);
                        inCriticalSection = false;
                } else if(token.queueIsEmpty() && leftCharacts > 0){
                        // if there are no more processes waiting for token, request token again
                        reinitialize(leftCharacts);
                        inCriticalSection = false;
                } else {
                        // there are no resources left, we kill the processes
                        System.out.println("Process index " + index + " lowering the others");
                        for (String uri : urls) {
                                if(!uri.contains(String.valueOf(index))){
                                        try {
                                                dest = (Suzuki_kasami_rmi) Naming.lookup(uri);
                                                dest.kill();
                                        } catch (MalformedURLException | RemoteException | NotBoundException e) {
                                                e.printStackTrace();
                                        }
                                }
                        }
                        try {
                                // the current process is killed
                                kill();
                        } catch (RemoteException e) {
                                e.printStackTrace();
                        }
                }

        }

        /**
         * Print the RN array
         */
        private void printRN(){
                System.out.print("\u001B[1mRN => [");
                for (Integer integer : RN) {
                        System.out.print(integer + ",");
                }
                System.out.print("]\u001B[0m\n");
        }

        // end private implementation
}